select
	dt,
	case when country = 'TW' then 'TW' else 'TH' end as region,
	count(distinct(user_id)) as dau,
	count(distinct(case when day_index = 1 then user_id else null end)) as new_users,
	count(distinct(case when paying_dimension.can.total_paid::float > 0 then user_id else null end)) as can_payers,
	count(distinct(case when paying_dimension.subscription.total_sub_paid::float > 0 then user_id else null end)) as sub_payers,
	sum(paying_dimension.can.total_paid::float) as can_revenue,
	sum(paying_dimension.subscription.total_sub_paid::float) as sub_revenue
from datamart.daily_users_dimension dud
	     left join prod_pg_users ppu on dud.user_id = ppu.id
where dt >= ADD_MONTHS(DATE_TRUNC('month', current_date), -2)
  AND dt < current_date
  and app = 'goodnight'
  and (country = 'TH' or (country='TW' and locale = 'th'))
group by 1,2
order by 1