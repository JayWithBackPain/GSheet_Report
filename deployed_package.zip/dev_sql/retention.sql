DROP TABLE if exists daily_users_temp;
CREATE TEMP TABLE daily_users_temp AS
SELECT
	dt,
	case when country = 'TW' then 'TW' else 'TH' end as region,
	user_id,
	case when day_index = 1 then true else false end as is_new
FROM datamart.daily_users_dimension dud
	     left join prod_pg_users ppu on dud.user_id = ppu.id
WHERE
	app = 'goodnight'
  AND dt >= ADD_MONTHS(DATE_TRUNC('month', current_date), -2) - INTERVAL '30 days'
  AND dt < current_date;

-- Step 2: 建立日期序列 (不變)
WITH RECURSIVE date_series(dt) AS (
	SELECT (ADD_MONTHS(DATE_TRUNC('month', current_date), -2) - INTERVAL '30 days')::DATE
	UNION ALL
	SELECT (dt + INTERVAL '1 day')::DATE
	FROM date_series
	WHERE dt < current_date - 1
),

-- Step 3: 計算每個同類群組 (cohort) 的 D7 和 D30 留存用戶數
               retention_counts AS (
	               SELECT
		               cohort.dt AS cohort_date,
		               cohort.region, -- <--- 新增
		               -- 計算 D7 回訪的使用者
		               count(distinct case when DATEDIFF(day, cohort.dt, activity.dt) = 7 then cohort.user_id end) as all_d7_retained,
		               COUNT(DISTINCT CASE WHEN cohort.is_new AND DATEDIFF(day, cohort.dt, activity.dt) = 7 THEN cohort.user_id END) AS new_d7_retained,
		               -- 計算 D7 回訪的使用者
		               count(distinct case when DATEDIFF(day, cohort.dt, activity.dt) = 30 then cohort.user_id end) as all_d30_retained,
		               COUNT(DISTINCT CASE WHEN cohort.is_new AND DATEDIFF(day, cohort.dt, activity.dt) = 30 THEN cohort.user_id END) AS new_d30_retained
	               FROM
		               daily_users_temp AS cohort
			               LEFT JOIN
		               daily_users_temp AS activity
			               -- 修改: JOIN 條件也需考慮 region，確保 cohort 和 activity 屬於同一個 region
		               ON cohort.user_id = activity.user_id AND  activity.dt > cohort.dt
	               WHERE
		               DATEDIFF(day, cohort.dt, activity.dt) IN (7, 30)
	               GROUP BY
		               cohort.dt, cohort.region
               ),

-- Step 4: 計算每個同類群組的總人數 (分母)
               cohort_sizes AS (
	               SELECT
		               dt AS cohort_date,
		               region,
		               count(distinct(user_id)) as dau_size,
		               COUNT(DISTINCT CASE WHEN is_new THEN user_id END) AS new_size
	               FROM
		               daily_users_temp
	               GROUP BY
		               dt, region
               ),

-- Step 5: 計算每日留存率
-- 修改點: JOIN 條件加上 region
               daily_retention_rates AS (
	               SELECT
		               cs.cohort_date,
		               cs.region,
		               -- D7 Retention Rates
		               (rc.all_d7_retained::FLOAT) / NULLIF(cs.dau_size, 0) AS all_d7_retention,
		               (rc.new_d7_retained::FLOAT) / NULLIF(cs.new_size, 0) AS new_d7_retention,
		               -- D30 Retention Rates
		               (rc.all_d30_retained::FLOAT) / NULLIF(cs.dau_size, 0) AS all_d30_retention,
		               (rc.new_d30_retained::FLOAT) / NULLIF(cs.new_size, 0) AS new_d30_retention
	               FROM
		               cohort_sizes cs
			               LEFT JOIN
		               retention_counts rc ON cs.cohort_date = rc.cohort_date AND cs.region = rc.region -- <--- 修改: JOIN 條件加上 region
               )

-- Step 6: 最終輸出
-- 修改點: 1. 建立 date_region_scaffold 2. LAG 函數中加入 PARTITION BY region
		, date_region_scaffold AS (
	SELECT dt, region
	FROM date_series
		     CROSS JOIN (SELECT 'TW' AS region UNION ALL SELECT 'TH' AS region)
),
		       agg as (
			       SELECT
				       drs.dt AS dt,
				       drs.region, -- <--- 新增 region 欄位
				       -- D7 retention: 在每個 region 內部分別計算 LAG
				       COALESCE(LAG(dr.all_d7_retention, 7) OVER (PARTITION BY drs.region ORDER BY drs.dt), 0) AS all_d7_retention_rate,
				       COALESCE(LAG(dr.new_d7_retention, 7) OVER (PARTITION BY drs.region ORDER BY drs.dt), 0) AS new_d7_retention_rate,
				       -- D30 retention: 在每個 region 內部分別計算 LAG
				       COALESCE(LAG(dr.all_d30_retention, 30) OVER (PARTITION BY drs.region ORDER BY drs.dt), 0) AS all_d30_retention_rate,
				       COALESCE(LAG(dr.new_d30_retention, 30) OVER (PARTITION BY drs.region ORDER BY drs.dt), 0) AS new_d30_retention_rate
			       FROM
				       date_region_scaffold drs
					       LEFT JOIN
				       daily_retention_rates dr ON drs.dt = dr.cohort_date AND drs.region = dr.region
		       )
select *
from agg where dt >= ADD_MONTHS(DATE_TRUNC('month', current_date), -2)
order by dt asc;

-- Step 8: 刪除臨時表
DROP TABLE daily_users_temp;